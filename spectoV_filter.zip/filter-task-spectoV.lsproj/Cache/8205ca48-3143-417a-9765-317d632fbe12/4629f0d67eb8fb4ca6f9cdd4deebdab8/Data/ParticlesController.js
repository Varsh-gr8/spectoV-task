// -----JS CODE-----
// ParticlesController.js
// Version: 1.1.0
// Event: Initialized
// Description: The primary script that drives the particles controller asset. Has
// a large assortment of exposed inputs and the logic to actually modify the 
// template content based on these inputs


// @input bool addParticles {"label":"Particles"}
// @ui {"widget":"group_start", "label":"Particles Properties", "showIf":"addParticles"}
// @input int particleIndex {"label": "Particle", "widget":"combobox", "values":[{"label":"Bokeh", "value":0}, {"label":"Confetti", "value":1}, {"label":"Flower Petals", "value":2}, {"label":"Fireworks", "value":3}, {"label":"Balloons", "value":4}, {"label":"Custom", "value":5}]}
// @input Asset.Material customParticleMaterial {"label":"Custom Particle", "showIf": "particleIndex", "showIfValue": 5}
// @input float particlesIntensity = 1.0 {"widget":"slider", "min":0.0, "max":1.0}
// @input vec3 emitterColorMin {"widget":"color", "label":"Color A"}
// @input vec3 emitterColorMax {"widget":"color", "label":"Color B"}
// @input float particleAlpha = 1.0 {"widget":"slider", "min":0.0, "max":1.0, "step":0.1, "label":"Alpha"}
// @ui {"widget":"group_end"}


//@ui {"widget":"separator"}

// @input bool hideMe {"label": "Advanced"}
// @input SceneObject[] particles {"label":"Particles", "showIf": "hideMe"}
// @input Component.MaterialMeshVisual customParticleMesh {"label":"Particle Mesh", "showIf": "hideMe"}

/**
 * Toggles the enabled state of elements in a given set based on the provided index.
 * If the index is 5, additional configuration is applied, including setting custom
 * materials to a particle mesh.
 * 
 * @param {sceneObject[]} set - An array of objects, whose enabled property is toggled.
 * @param {number} index - The index of the element in the set to be enabled. If null, all elements are disabled.
 */
function swapSet(set, index) {
    for (var i = 0; i < set.length; i++) {
        set[i].enabled = false; 
    }
    if (index != null) {
        set[index].enabled = true;
        if (index == 5) {
            if (!script.customParticleMesh) {
                print("PartyTimeController, ERROR: Please assign Custom Particle Mesh object");
                return;
            }

            if (!script.customParticleMaterial) {
                print("PartyTimeController, WARNING: Please assign Custom Particle material");
                return;
            }

            script.customParticleMesh.clearMaterials();
            script.customParticleMesh.addMaterial(script.customParticleMaterial);
            var particle = set[index];
            var scriptComponents = particle.getComponents("Component.ScriptComponent");
            for (var j = 0; j < scriptComponents.length; j++) {
                var scriptComponent = scriptComponents[j];
                scriptComponent.emitter = script.customParticleMaterial;
            }
        }
    }
}

/**
 * Configures particle properties based on script settings. If `addParticles` is true, it configures
 * the particle system at `particleIndex`. It sets particle amount, colors, and alpha based on script
 * properties. Uses `swapSet` to manage enabling and disabling of particle systems in the set.
 */
function configureParticles() {
    if (script.addParticles) {
        swapSet(script.particles, script.particleIndex);

        var particle = script.particles[script.particleIndex]; 
        var scriptComponents = particle.getComponents("Component.ScriptComponent");
        for (var i = 0; i < scriptComponents.length; i++) {
            var scriptComponent = scriptComponents[i];
            scriptComponent.particlesIntensity = script.particlesIntensity;
            scriptComponent.emitterColorMin = script.emitterColorMin;
            scriptComponent.emitterColorMax = script.emitterColorMax;
            scriptComponent.particleAlpha = script.particleAlpha;
        }
    } else {
        swapSet(script.particles);
    }
}

// Initialize and configure particles
configureParticles();

