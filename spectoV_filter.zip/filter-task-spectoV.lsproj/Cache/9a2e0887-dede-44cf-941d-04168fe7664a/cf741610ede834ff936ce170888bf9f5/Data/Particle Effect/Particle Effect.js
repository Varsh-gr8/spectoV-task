//@input Asset.Material particleMat;
//@input Asset.RenderMesh particlesMesh;
//@input Asset.Texture texture;
//@input float speed;


//@ui {"widget":"group_start", "label":"material settings"}
//@input int count;
//@input float lifeTime;
//@input vec3 initialLocation;
//@input vec3 spawnSphere;
//@input vec3 velocityMin;
//@input vec3 velocityMax;
//@input vec2 sizeStart;
//@input vec2 sizeEnd;
//@input float gravity;
//@input vec2 rotationRate;
//@input float fadeToAlpha;
//@ui {"widget":"group_end"}

const parentSO = script.getSceneObject();
let mat,mesh,so,particleObj,particleSO,particleMat = script.particleMat, texture = script.texture, speed = script.speed;
let sparklesSpeed = 0.3, snowSpeed = 0.7, bokehSpeed = 1.0, headSpeed = 0.7;

function init(){
    if(!validateInputs()){
        return;
    }
    setMatParams();
    setSceneObjects();
    script.createEvent('OnDisableEvent').bind(function(){
        let particleObjects = [so,particleObj,particleSO];
        enableSceneObjects(particleObjects,false);
        
    });
    script.createEvent('OnEnableEvent').bind(function(){
        let particleObjects = [so,particleObj,particleSO];
        enableSceneObjects(particleObjects,true);
    });
    bindInputs();
    
}

init();

// Helpers

function setSceneObjects(){
    let particleObjects = [particleObj,particleSO];
    cleanSceneObjects(particleObjects);
         particleObj = createParticleSO('particleEmitter',script.particleMat);
}

function cleanSceneObjects(objs){
    for(let i=0;i<objs.length;i++){
        if(objs[i] !== undefined && objs[i] !== null){
            objs[i].destroy();
        }
    }
}

function enableSceneObjects(objs,enabled){

    for(let i=0;i<objs.length;i++){
        if(objs[i]!==undefined){
                    objs[i].enabled = enabled;
        }
    }
}
    
function createParticleSO(objName,mat){
    let so = global.scene.createSceneObject(objName);
    so.setParent(parentSO);
    mesh = so.createComponent('Component.RenderMeshVisual');
    mesh.mesh = script.particlesMesh;
    mat = mat.clone();
    mesh.addMaterial(mat);
    if(texture){
        mat.mainPass.mainTexture = texture;
    }
    else{
        mesh.enabled = false;
    }
    if(script.speed - mat.mainPass.timeOffset>0){
        mat.mainPass.timeGlobal = script.speed;
    }
    so.setRenderLayer(parentSO.getRenderLayer());
    var pos = new vec3(0,0,0);
    so.getTransform().setWorldPosition(pos);
    return so;
}


function setMatParams(){
    particleMat.mainPass.instanceCount = script.count > 0 ? script.count : 1;
    particleMat.mainPass.lifeTimeConstant = script.lifeTime;
    particleMat.mainPass.spawnLocation = script.initialLocation;
    particleMat.mainPass.spawnSphere = script.spawnSphere;
    particleMat.mainPass.velocityMin = script.velocityMin;
    particleMat.mainPass.velocityMax = script.velocityMax;
    particleMat.mainPass.sizeStart = script.sizeStart;
    particleMat.mainPass.sizeEnd = script.sizeEnd;
    particleMat.mainPass.gravity = script.gravity;
    particleMat.mainPass.rotationRate = script.rotationRate;
    particleMat.mainPass.alphaEnd = script.fadeToAlpha;
}

function validateInputs(){
    if(!script.texture){
        print('Particles CC Warning: please add a texture')
    }
    return true;
}

// Property Binding
function bindInputs(){
    bindTexture('texture');
    bindSpeed('speed');
    bindProperty('count','instanceCount');
    bindProperty('lifeTime','lifeTimeConstant');
    bindProperty('initialLocation','spawnLocation');
    bindProperty('spawnSphere','spawnSphere');
    bindProperty('velocityMin','velocityMin'); 
    bindProperty('velocityMax','velocityMax'); 
    bindProperty('sizeStart','sizeStart'); 
    bindProperty('sizeEnd','sizeEnd'); 
    bindProperty('gravity','gravity'); 
    bindProperty('rotationRate','rotationRate'); 
    bindProperty('fadeToAlpha','alphaEnd'); 
    
    
}

function bindTexture(inputName) {
    Object.defineProperty(script, inputName, {
        set: function(val) {
            texture = val;
            mesh.enabled = true;
            setSceneObjects();
        },
        get: function(val) {
            return texture;
        }
    });
}

function bindSpeed(inputName) {
    Object.defineProperty(script, inputName, {
        set: function(val) {
            speed = val;
            setSceneObjects();
        },
        get: function(val) {
            return speed;
        }
    });
}

function bindProperty(inputName,propName) {
    Object.defineProperty(script, inputName, {
        set: function(val){
            particleMat.mainPass[propName] = val;
            setSceneObjects();
        },
        get: function(){
            return  particleMat.mainPass[propName];
        }
    });
}


