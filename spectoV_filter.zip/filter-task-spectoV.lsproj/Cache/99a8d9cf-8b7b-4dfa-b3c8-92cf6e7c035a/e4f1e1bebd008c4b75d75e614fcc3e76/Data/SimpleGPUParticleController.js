// SimpleGPUParticlesController.js
// Version: 1.1.0
// Event: On Awake
// Description: Controls parameters on the GPU Particles material

// @input Component.RenderMeshVisual[] particles

// @ui {"widget":"group_start", "label":"Particles Settings"}
    // @input float particlesIntensity = 0.1 {"widget":"slider", "min":0.0, "max":1.0, "step":0.01}
    // @input bool advanced
    // @input int minParticles = 0 {"showIf":"advanced", "min":0}
    // @input int maxParticles = 50000 {"showIf":"advanced", "min":1} 
    // @input vec3 emitterColorMin {"widget":"color"}
    // @input vec3 emitterColorMax {"widget":"color"}
    // @input float particleAlpha = 1.0 {"widget":"slider", "min":0.0, "max":1.0, "step":0.1}
// @ui {"widget":"group_end"}


// validate inputs
function validateInputs() {
    for (var i = 0; i < script.particles.length; i++) {
        if (script.particles[i] == null) {
            print("ERROR: pleae make sure all Particles Visuals are assigned.");
            return false;
        }
        if (script.particles[i].mainMaterial == null) {
            print("ERROR: please make sure all Particle Visuals have Particle Materials assigned.");
            return false;
        }
         if (script.particles[i].mainMaterial.mainPass == null) {
            print("ERROR: please make sure all Particle Materials have Main Pass.");
            return false;
        }
        var meshVisual = script.particles[i];
        if(script.minParticles == 0 && script.particlesIntensity == 0){
            // Disable Particles visual when particle count is 0.
            // This is because instance count for particles materials must be >= 1
            print("ERROR: please make sure minParticles and particlesIntensity is bigger than 1");
            meshVisual.enabled = false;
            return false;
        } else {
            meshVisual.enabled = true;
            var pass = script.particles[i].mainMaterial.mainPass;
            pass.colorMinStart = script.emitterColorMin;
            pass.colorMaxStart = script.emitterColorMax;
        }
    }
    return true;
}


function onStart() {
    if(!validateInputs()){
        return;   
    } 
    var updateEvent = script.createEvent("UpdateEvent").bind(onUpdate);
}

// onUpdate
function onUpdate(eventData) {    
    for (var i = 0; i < script.particles.length; i++){ 
        var pass = script.particles[i].mainMaterial.mainPass;
        pass.instanceCount = lerp(script.minParticles, script.maxParticles, script.particlesIntensity);
        pass.alphaStart = script.particleAlpha;
        pass.externalTimeInput = getTime() + 25;
    }
}
var startEvent = script.createEvent("OnStartEvent").bind(onStart);


// lerp
function lerp(a, b, t) {
    return a * (1.0 - t) + b * t;
}