// Eyewear3D.js
//
// Version 1.0
//

//@input Asset.ObjectPrefab model;
//@input float scale;
//@input Asset.ObjectPrefab bindingPrefab;
//@input string offsets;

const headwearRootName = "Headwear Root";
const lensObjectName = "C_hat_GEO";
const baseOffset = new vec3(0,-43.5,4.5);
let inputVals = {
    model: script.model,
};
let instance = null;
let bindingSo = null;
let modelRoot = null;
let renderLayer = null;

function init() {
    const so = script.getSceneObject();
    bindingSo = script.bindingPrefab.instantiate(so);
    fixRenderLayers(so);
    modelRoot = findChild(so, headwearRootName);
    if (!modelRoot) {
        print("cannot find models root");
        return;
    }
    modelRoot.getTransform().setLocalPosition(baseOffset.add(setOffset()));
    modelRoot.getTransform().setLocalScale(new vec3(script.scale, script.scale, script.scale));
    setupProperties();
    instantiateModel(inputVals.model);
}

function instantiateModel(model) {
    if (instance) {
        instance.destroy();
        instance = null;
    }
    if (!model) {
        return;
    }
    
    instance = model.instantiate(modelRoot);
    fixRenderLayers(instance);
}

function setOffset(){
    if(script.offsets){
        try{
          return createVec3FromString(script.offsets);
        }
        catch(e){
            return new vec3(0,0,0);
        }
    }
    else{
        return new vec3(0,0,0);
    }
}

function createVec3FromString(str) {
    // Split the string by commas and convert each part to a number
    const parts = str.split(',').map(Number);
    // Check if the parts array has exactly 3 elements
    if (parts.length !== 3) {
       return new vec3(0,0,0);
    }
    return new vec3(parts[0],parts[1],parts[2]);
}


function setupProperties() {
    script.createEvent("OnDisableEvent").bind(function() {
        if (bindingSo) {
            bindingSo.enabled = false;
        }
    });
    script.createEvent("OnEnableEvent").bind(function() {
        if (bindingSo) {
            bindingSo.enabled = true;
        }
    });
    
    Object.defineProperties(script, {
        model: {
            set: function(value) {
                inputVals.model = value;
                instantiateModel(inputVals.model);
            },
            get: function() {
                return inputVals.model;
            }
        }
    });
}

function findChild(root, name) {
    if (root.name == name) {
        return root;
    }
    
    for (let i=0; i<root.getChildrenCount(); i++) {
        const child = root.getChild(i);
        let found = findChild(child, name);
        if (found) {
            return found;
        }
    }
    
    return null;
}

function fixRenderLayers(so) {
    const layer = getCameraRenderLayer(so);
    if (!layer) {
        print("cannot find render layer for camera above so: "+so);
        return;
    }
    assignRenderLayer(so, layer);
}

function assignRenderLayer(root, layer) {
    forEachChild(root, function(so) {
        so.layer = layer;
    });
}

function getCameraRenderLayer(so) {
    const cam = getParentCamera(so);
    if (!cam) {
        print("could not find parent camera for object: "+so.name);
        return null;
    }
    
    return cam.renderLayer;
}

function getParentCamera(so) {
    if (!so) {
        return null;
    }
    
    const cam = so.getComponent("Component.Camera");
    if (cam) {
        return cam;
    }
    
    return getParentCamera(so.getParent());
}

function forEachChild(so, func) {
    func(so);
    
    for (let i=0; i<so.getChildrenCount(); i++) {
        forEachChild(so.getChild(i), func);
    }
}

init();