// Main Controller
//
// Made with Easy Lens

//@input Component.ScriptComponent baseball_cap
//@input Component.ScriptComponent confetti_particles


try {

script.baseball_cap.enabled = true;
script.confetti_particles.enabled = true;
script.confetti_particles.count = 1; // Single piece of confetti
script.confetti_particles.sizeStart = new vec2(8.0, 0.5);
script.confetti_particles.sizeEnd = new vec2(8.0, 0.5);
script.confetti_particles.initialLocation = new vec3(0, 100, 0);
script.confetti_particles.spawnSphere = new vec3(1, 1, 1); // Minimal spawn area for a single piece
script.confetti_particles.gravity = -5.0; 
script.confetti_particles.speed = 0.7; 
script.confetti_particles.velocityMax = new vec3(0, 0, 0);
script.confetti_particles.velocityMin = new vec3(0, 0, 0);

} catch(e) {
  print("error in controller");
  print(e);
}
