///////////////////////////////////////////////////////////////////////////////
/// This script not necessary for the post effect to wrok. 
/// It simply helps users to scroll through all avalible LUT styles, the
/// name of the LUT style in preview will be printed in the Logger window.
/// Once located the ideal look in mind, you could remove this script and
/// directly assign the textue on to the Color Correction material.
///////////////////////////////////////////////////////////////////////////////

//@input int style = 1 {"widget": "slider", "min": 0, "max": 41, "step": 1}
//@input Component.PostEffectVisual postEffect
//@input Asset.Texture[] lutTex

script.postEffect.mainPass.baseTex = script.lutTex[script.style];
var name = script.lutTex[script.style].name;

print("You are using the " + name + " style");
